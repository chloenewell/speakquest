# SpeakQuest

SpeakQuest is an audio-first foundational English literacy adventure for beginning multilingual learners ages 7–10. The working Sound Valley mission teaches six letter sounds, blending and controlled word reading. An educator-facing scope and sequence maps that starting point into a proposed broader A1-to-A2 language pathway.

## GitHub Pages portfolio hosting

Run `pnpm run prepare:github-pages` to create a clean, ready-to-upload GitHub
Pages package. See [GITHUB-PAGES.md](GITHUB-PAGES.md) for the publishing steps,
privacy boundaries and rebuild instructions. This is a complete playable
static site, not only a code repository.

## Local development

Use the managed **SpeakQuest** preview workflow. In this pnpm workspace:

- `pnpm --filter @workspace/speakquest run typecheck`
- `pnpm --filter @workspace/speakquest run test:metrics` runs focused aggregation, comparison, recommendation and source-isolation checks using Node's built-in test runner.
- `pnpm --filter @workspace/speakquest run test:recorder` checks microphone permissions, late grants, interruptions, clip cleanup and scoring separation with browser API fakes.
- `pnpm --filter @workspace/speakquest run dev` is the managed workflow's command; its environment supplies `PORT` and `BASE_PATH`.
- `node scripts/src/generate-phonics.mjs` regenerates the small bundled WAV files; requires eSpeak NG.

## The mission

One original, cumulative sequence, with no proprietary lessons or assets:

1. Pip models listening and tapping.
2. Identify initial sounds using spoken phonemes and pictures.
3. Explicitly introduce and match **m, s, t, p, a, i**.
4. Watch connected-sound tiles blend **mat**.
5. Decode **sat** and **tap** with optional scaffolds.
6. Independently decode fresh items **map, sit, pit**.
7. Celebrate and receive a practice recommendation.

All decoding words, including distractors, use only the six taught correspondences. Vocabulary used in adult instructions is not intended as decodable reading material. The mission does not introduce sentence-level lessons or conversations. There is no microphone requirement or punitive streak.

Sound identification comes before grapheme instruction because it is oral phonemic-awareness work. The six letter correspondences are explicitly modeled before CVC reading. Transfer target words are not automatically spoken or pictured before a response. Audio answer options are always available; target-specific help changes scoring to assisted.

## Audio and accessibility

Bundled audio uses eSpeak NG phoneme-mode input for isolated phonemes, controlled words, and connected blends. Consonants are not generated from their letter names, and no extra schwa is explicitly appended. Separate files make phoneme playback independent of browser speech voices. Connected blends are a single phoneme utterance, not concatenated letter names.

Browser speech synthesis supplies spoken instructions. Voice availability and quality vary by browser and operating system. Playback failure produces a retry notice; captions are available. The prototype uses synthetic speech, which needs expert phonetics review and listening checks with children before instructional release. Synthetic audio is not a substitute for professionally recorded, validated pronunciation models.

Large targets, keyboard focus, captions, reduced-motion support, a Calm setting, help and replay controls support independent use. Decode answer options can be reached using Tab and activated with Enter or Space.

### Optional read-aloud

The **sat**, **tap**, **map**, **sit** and **pit** word tasks offer **Read aloud (optional)**. The three-step routine is available as text, icons and spoken instructions: record, say the printed word, stop and listen. The instructions do not say the target word. **Start recording** is the only action that requests microphone permission, using the browser's `getUserMedia` and `MediaRecorder` APIs over HTTPS. Permission denial, unavailable hardware, restricted embedded previews and unsupported browsers leave the complete tap-answer route available.

Recording stops at 15 seconds, with a 2 MB safety limit. The browser chooses its supported recording format. Stop, listen-back, stop-playback, discard and use-taps controls are explicit. App audio and answer controls are paused during capture or listen-back, so target models are not played into the microphone. The learner can return to tapping at any time.

Clips are memory-only object URLs. Nothing is uploaded, downloaded, transcribed or retained in browser storage. Microphone tracks stop on recording stop; clips, tracks and URLs are cleaned up on discard, task exit, restart or interruption. Hiding the tab clears the current clip, and a permission granted after cancellation immediately has its tracks stopped.

Speaking is participation, not an automatically scored answer. The existing answer choices still determine task correctness and progression. Recording does not count as a hint or model, and it cannot establish independent reading accuracy. A later target-specific hint still makes the scored response assisted.

## Technical architecture

- React, Vite, TypeScript, Wouter and Tailwind in `artifacts/speakquest`.
- `src/lib/learning.ts`: controlled content, event schema, separate real/synthetic persistence, aggregates, exports, prototype recommendations.
- `src/lib/audio.ts`: local phoneme/word audio and browser narration.
- `src/lib/recorder.ts`: transient local capture, listen-back, permission handling and lifecycle cleanup.
- `src/components/mission/read-aloud.tsx`: optional child-facing speaking routine and explicit controls.
- `src/pages/play.tsx`: task lifecycle, explicit teaching, scoring and corrective modeling.
- `/insights`: side-by-side selected-session and cohort evidence, anonymous session timelines, configurable recommendation threshold, exports and confirmed reset.
- `/schema`: human-readable event and metric documentation.
- `/scope-and-sequence`: educator-facing instructional order, independent-use scaffolds, progression evidence and a proposed broader English-language roadmap.
- `src/lib/curriculum.ts`: original curriculum phase descriptions, available/planned status and support-fading principles. This content does not alter gameplay or recorded metrics.

No backend or database is used for learner data. The template's API package is unrelated to learner telemetry.

## Scope and sequence for educators

Open **Scope & Sequence** in the main navigation or the educator link on the home page. Each phase presents a goal and expandable details covering prerequisites, an example activity, support for independent use and evidence for the next step.

The foundational sequence distinguishes six phases available in Mission 1 from two planned extensions:

1. Listen-and-tap orientation, available.
2. Spoken vocabulary and oral-language readiness, planned as a dedicated warm-up.
3. Initial-phoneme identification, available.
4. Explicit introduction of m, s, t, p, short a and short i, available.
5. Connected blending demonstration, available.
6. Controlled CVC decoding, available.
7. Mixed and delayed cumulative review, planned.
8. Fresh target-word transfer within the mission, available.

The proposed language roadmap extends from familiar vocabulary and listening routines through short spoken exchanges, reading for meaning and writing, toward communication across familiar situations. These are educator planning phases, not additional playable lessons. The page includes a link to the Council of Europe's CEFR background.

Support fades from modeling to guided practice, independent application and transfer, while accessibility controls stay available. Progression evidence distinguishes vocabulary comprehension, decoding, listening, spoken interaction and writing rather than mapping a phonics percentage to a language level. Home-language experience is treated as a strength, and a no-microphone answer path is retained.

## Privacy

Events live only in this browser's local storage. Session IDs are random and newly generated for each adventure, not stable learner identifiers. No names, emails, authentication, third-party analytics or external font requests are needed. Optional voice clips are never persisted or uploaded. Data is device/browser-specific and is **not a multi-student production analytics system**.

The browser or operating system controls how its speech-synthesis implementation obtains voices. SpeakQuest does not send telemetry or learner identifiers to a speech provider. Use bundled audio and captions where platform speech behavior is unsuitable.

Real events and synthetic events have separate storage keys. Demo loading never overwrites real play. Export and reset apply only to the selected source. Clearing browser data also removes local records. Exported CSV/JSON files are the user's responsibility.

### Individual and cohort insights

An individual is one selected anonymous adventure, not a persistent learner identity. The cohort is every session in this browser for the selected source, including that selected session. Repeat adventures can belong to the same child, so cohort size is not a unique-student count or a cross-device class count.

The session selector controls every individual comparison, the timeline and the next-step recommendation. Real play remains the default source. Synthetic sessions remain explicitly labeled and isolated. CSV/JSON exports contain the entire selected source's cohort, not just the selected session. Reset confirms deletion of that same source only.

Accuracy, fresh transfer, independent/assisted success, success after modeling, replay/help frequency and time are shown side by side. Percentages include counts and denominators. Cohort percentages pool observed tasks rather than averaging per-session rates. Skills or outcomes with no observations display **Not observed**, not 0%.

First-try and transfer accuracy use first scored answers with no prior help. Independent and assisted success use all answered tasks as the denominator; unsolved tasks remain in that denominator. Corrective models awaiting a later answer are shown as pending and excluded from the observed after-model denominator. Initial teaching is not corrective modeling.

Replay/help frequency shows counts and requests per started task, including tutorial and blend tasks. Time shows total elapsed minutes plus seconds per timed task, not an attention estimate. Each task contributes at most one end record; open tasks without an end record are excluded. Stage completion requires its final item.

## Event schema

Every event includes:

| Field | Meaning |
| --- | --- |
| `name` | Event name |
| `timestamp` | ISO timestamp |
| `sessionId` | Adventure-scoped anonymous UUID |
| `taskId`, `skillId`, `itemId` | Content context; mission events use mission context |
| `attempt` | One-based scored attempt; mission-level events may use zero |
| `correctness` | Boolean for submitted/scored outcomes, otherwise null |
| `hintLevel` | Zero before assistance; increments on hints/errors |
| `responseTimeMs` | Elapsed time since task start |
| `itemType` | `practiced` or `fresh` |
| `stage`, `phoneme`, `taskType` | Breakdown dimensions |
| `source` | `real` or `synthetic` |

Names: `session_started`, `task_started`, `sound_played`, `audio_replayed`, `answer_submitted`, `hint_requested`, `model_shown`, `task_completed`, `task_abandoned`, `mission_completed`.

Optional participation adds only event names with the same non-identifying content/session context, never audio, transcripts, device labels or new voice-related fields:

| Event | Meaning |
| --- | --- |
| `microphone_permission_requested` | Start recording chosen; browser request begins |
| `microphone_permission_denied` | Access denied by browser, user or embedding policy |
| `microphone_unavailable` | Unsupported browser or microphone could not open |
| `read_aloud_started` | Temporary capture actually began |
| `read_aloud_stopped` | A non-empty clip became ready for listen-back |
| `read_aloud_played` | Own-voice playback successfully began, not a model or hint |
| `read_aloud_discarded` | Pending capture or clip cleared intentionally or on task exit |
| `read_aloud_interrupted` | Clip/capture cleared on hidden tab, page leave or disconnected microphone |
| `read_aloud_failed` | Empty/oversized clip or recording error, without raw error details |

Every participation event forces `correctness` to `null` at the persistence boundary. It does not create `answer_submitted`, `task_completed`, hints or models, and does not enter accuracy numerators or denominators. Schema and Insights timelines include the event names; CSV/JSON contain metadata only.

First-attempt accuracy uses the first scored response per item/session and requires no prior assistance. Independent and assisted success are mutually exclusive per item. Initial letter teaching and the blend demonstration are not corrective assistance and are not scored as answers. Success after modeling includes only corrective models with hint level greater than zero and an observed later answer. Transfer accuracy uses the first response on fresh items and requires no prior assistance. A correct answer after a hint is never independent mastery.

Stage completion means finishing the stage's final item. Explicit exit or page unload records task abandonment; abrupt device termination may not deliver an unload event. Time on task is elapsed wall-clock time for completed or abandoned tasks, not an attention measurement.

The Insights threshold defaults to 80% and is adjustable from 0 to 100%. It changes the selected session's practice recommendation without changing any recorded answer or metric. Wider progression evidence is described on the Scope & Sequence page.

## Validation status and limitations

Verification includes TypeScript checks, focused metric tests and preview checks. Full mission end-to-end testing, human phoneme listening review and observed learner usability sessions remain separate validation steps. Check mission routes, audio controls, repeated hints, exports, reset isolation, abandonment and dashboard updates in supported browsers before classroom use.

The focused read-aloud browser journey passed using real `MediaRecorder` with a synthetic tone stream, not a physical microphone. It checked opt-in timing, the spoken routine, capture, stop, listen-back, discard, URL/track cleanup, denied-access fallback, tap-only progression and transfer without a preplayed target model. Stored participation events remained unscored and contained no voice data. Actual browser permission prompts, microphone audibility and classroom/mobile device compatibility still need device-specific confirmation.

## Next iteration opportunities

- Professionally record and expert-review every phoneme, connected blend and instruction.
- Conduct observed usability sessions with beginning multilingual learners.
- Add automated browser coverage of the complete mission and event sequences.
- Evaluate more fresh transfer items and counterbalanced distractors.
- Study thresholds empirically before making any adaptive-learning claim.
- Consider institutional consent, retention and access controls only if a separate production multi-learner system is commissioned.
