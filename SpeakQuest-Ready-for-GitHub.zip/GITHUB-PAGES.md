# Publish SpeakQuest on GitHub Pages

The prepared package includes the complete playable site in **docs**, plus the
app's source code. No paid backend, API key, database or microphone is required.
Optional recording works on HTTPS when the browser and device allow it.

## First upload

1. On GitHub, create a **new public repository** named **speakquest**. Use a new
   repository so you do not replace your existing portfolio.
2. Extract the prepared ZIP on your computer. Open the
   **speakquest-github-pages** folder.
3. In the new repository, choose **uploading an existing file** or
   **Add file > Upload files**. Drag **docs**, **README.md** and **GITHUB-PAGES.md**
   into the upload area. Commit the files to **main**. These are all that hosting
   needs. The remaining source files can be uploaded afterward, in batches of
   fewer than 100 files if using GitHub's browser uploader.
4. Open the repository's **Settings > Pages**. Under **Build and deployment**,
   select **Deploy from a branch**, then **main** and **/docs**. Click **Save**.
5. Wait for GitHub to finish publishing. The Pages screen shows the actual
   website address. Add that address, not just the repository address, to your
   portfolio.

Do not upload the ZIP itself or put the docs folder inside another folder.
The repository should show `docs/index.html`.

## What an employer can try

- Start a new adventure and follow Pip's independent-use tutorial.
- Play the sound, letter, blending and controlled word-reading activities.
- Use the optional microphone to record and listen back, or complete every task
  by tapping.
- Open Insights to compare an anonymous adventure with the device-local cohort.
  Load the synthetic demo to explore a populated cohort without overwriting
  real gameplay.
- Explore Scope & Sequence and the event Schema.

Insights stay in the visitor's browser. Data from the Replit preview does not
automatically move to GitHub Pages. The synthetic demo is included in the app.
Voice clips remain temporary and are not uploaded.

## Links and refreshes

The Pages version uses links such as `#/play` and `#/insights`, so navigation
and refreshing work without a server. Its assets use relative paths, allowing
it to work in either a GitHub project repository or a portfolio subfolder.
The Replit preview keeps its existing clean URLs.

## Rebuild after changing the source

With Node.js 22 or later and pnpm 10.26.1 installed:

```sh
pnpm install --frozen-lockfile
pnpm --filter @workspace/speakquest run typecheck
pnpm run prepare:github-pages
```

The updated upload folder is
`generated-artifacts/github-pages/speakquest-github-pages`.
Upload the updated docs contents to the repository's docs folder.

The export excludes chat history, Git history, internal workspace notes,
environment files, original uploads and unrelated apps. Source packages under
lib and scripts are included to keep the workspace reproducible; the playable
site itself requires only the docs folder.
